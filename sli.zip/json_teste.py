import  jinja2


texto=open('./templates/Email.html', encoding='utf-8').read()

print(jinja2.Template(texto).render(nome='sergio'))